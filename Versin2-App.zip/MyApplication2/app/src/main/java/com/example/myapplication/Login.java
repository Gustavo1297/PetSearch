package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;

import com.example.myapplication.IniciarSesion.OnFragmentInteractionListener;

public class Login extends AppCompatActivity implements View.OnClickListener, IniciarSesion.OnFragmentInteractionListener, RegistrarUsuario.OnFragmentInteractionListener{

    Button btnIniciarSesion, btnRegistrarUsuario, btnEntrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        IniciarSesion fragmento1 = new IniciarSesion();

        getSupportFragmentManager().beginTransaction().add(R.id.contenedor, fragmento1);

        btnIniciarSesion = (Button) findViewById(R.id.btnIniciarSesion);
        btnRegistrarUsuario = (Button) findViewById(R.id.btnRegistrarUsuario);

        btnEntrar = (Button) findViewById(R.id.btnEntrar);

        btnIniciarSesion.setOnClickListener(this);
        btnRegistrarUsuario.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.btnIniciarSesion:
                IniciarSesion fragmento1 = new IniciarSesion();
                FragmentTransaction transition = getSupportFragmentManager().beginTransaction();
                transition.replace(R.id.contenedor, fragmento1);
                transition.commit();


                break;

            case R.id.btnRegistrarUsuario:
                RegistrarUsuario fragmento2 = new RegistrarUsuario();
                FragmentTransaction transition2 = getSupportFragmentManager().beginTransaction();
                transition2.replace(R.id.contenedor, fragmento2);
                transition2.commit();
                break;
        }

    }

    @Override
    public void onFragmentInteraction(Uri uri) { }

    public void entrarMetodo(View view){
            Intent intent = new Intent(this, Menu.class);
            startActivity(intent);
    }


    }


